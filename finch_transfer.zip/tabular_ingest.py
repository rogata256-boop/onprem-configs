"""
Row-by-row tabular ingestion pipeline.

For each row in a TSV/CSV file:
  1. Submit the row text to FFT for enrichment
  2. Inject configured relationships from column pairs
  3. Ingest the enriched document into Finch Analyst

Usage:
    python3 tabular_ingest.py <data_file> <api_key> [options]
"""

import datetime
import json
import logging
import sys
import uuid

import pandas as pd

from finch_clients import FinchClient, FinchAnalystClient

sys.stdout.reconfigure(encoding="utf-8")

logger = logging.getLogger(__name__)


def word_count(text):
    return len(text.split())


def find_entity(entities, label, entity_type, normalize=False):
    label_norm = label.replace(" ", "") if normalize else label
    for e in entities:
        if e.get("type") != entity_type:
            continue
        e_label = e.get("label", "")
        e_label_norm = e_label.replace(" ", "") if normalize else e_label
        if e_label_norm.lower() == label_norm.lower():
            return e
    return None


def make_relationship(predicate_type, subject_entity, object_entity, sentence, subject_val, object_val):
    subj_start = sentence.find(subject_val)
    subj_stop = subj_start + len(subject_val) if subj_start != -1 else 0
    obj_start = sentence.find(object_val)
    obj_stop = obj_start + len(object_val) if obj_start != -1 else 0

    def entity_ref(e, start, stop):
        ref = {
            "anchor": e["label"],
            "internalRef": e.get("internalRef", ""),
            "label": e["label"],
            "start": start,
            "stop": stop,
            "type": e["type"],
        }
        if e.get("syntheticId"):
            ref["syntheticId"] = e["syntheticId"]
        if e.get("disambiguated"):
            ref["id"] = e["disambiguated"]["id"]
        return ref

    return {
        "confidence": 1.0,
        "evidence": {
            "sentence": sentence,
            "start": 0,
            "stop": len(sentence),
        },
        "originalType": predicate_type,
        "predicate": {
            "bidirectional": False,
            "properties": {"status": "Current"},
            "type": predicate_type,
        },
        "subject": entity_ref(subject_entity, subj_start, subj_stop),
        "object": entity_ref(object_entity, obj_start, obj_stop),
    }


def inject_relationships(enrichment, row, subject_col, subject_type, rel_specs):
    entities = enrichment.get("entities", [])
    sentence = "\t".join(row.index) + "\n" + "\t".join(str(row[c]) for c in row.index)
    subject_val = row[subject_col]

    subject_entity = find_entity(entities, subject_val, subject_type)
    if not subject_entity:
        logger.warning("No %s entity found for '%s', skipping relationship injection.", subject_type, subject_val)
        return enrichment

    new_rels = []
    for spec in rel_specs:
        object_val = row.get(spec["col"], "")
        if not object_val:
            continue
        normalize = spec["type"] == "PAYMENT_CARD"
        object_entity = find_entity(entities, object_val, spec["type"], normalize=normalize)
        if not object_entity:
            logger.warning("No %s entity found for '%s', skipping.", spec["type"], object_val)
            continue
        new_rels.append(make_relationship(spec["predicate"], subject_entity, object_entity, sentence, subject_val, object_val))

    enrichment.setdefault("relationships", []).extend(new_rels)
    return enrichment


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Enrich and ingest tabular data row-by-row into Finch Analyst."
    )
    parser.add_argument("data_file", help="Path to TSV or CSV data file")
    parser.add_argument("api_key", nargs="?", help="Bearer token for Finch APIs")
    parser.add_argument("--separator", default="\t", help="Field separator (default: tab)")
    parser.add_argument("--title-col", default=None,
                        help="Column to use as document title (default: FFT summarize)")
    parser.add_argument("--subject-col", default="personNameTransliterated",
                        help="Column for relationship subject (default: personNameTransliterated)")
    parser.add_argument("--subject-type", default="PERSON",
                        help="FFT entity type for subject (default: PERSON)")
    parser.add_argument("--relationships", nargs="+", metavar="COL:PREDICATE:TYPE",
                        default=[
                            "nationalID:hasIdentifier:PERSON_IDENTIFIER",
                            "cardNumber:hasPaymentCard:PAYMENT_CARD",
                        ],
                        help="Relationships as COL:PREDICATE:ENTITY_TYPE")
    parser.add_argument("--source-name", default="Text", help="Source name (default: 'Text')")
    parser.add_argument("--source-country", default=None, help="Source country (sets source.location.country)")
    parser.add_argument("--document-url", default=None, help="URL to include as documentURL (omitted if not provided)")
    parser.add_argument("--filter-sets", nargs="+", default=["Text Evaluation"], metavar="SET")
    parser.add_argument("--write-payload", action="store_true",
                        help="Write each POST payload to <data_file>.<row>.post_payload.json")
    parser.add_argument("--write-enrichment", action="store_true",
                        help="Write each row's FFT enrichment JSON (with relationships) to <data_file>.row<N>.enrichment.json")
    parser.add_argument("--skip-ingest", action="store_true",
                        help="Skip FA ingestion (useful with --write-enrichment)")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level, format="%(levelname)s: %(message)s", stream=sys.stderr)

    # Parse relationship specs
    rel_specs = []
    for spec in args.relationships:
        parts = spec.split(":")
        if len(parts) != 3:
            logger.error("Invalid relationship spec '%s'. Expected COL:PREDICATE:TYPE.", spec)
            sys.exit(1)
        rel_specs.append({"col": parts[0], "predicate": parts[1], "type": parts[2]})

    df = pd.read_csv(args.data_file, sep=args.separator, dtype=str).fillna("")

    import requests as _requests
    try:
        with FinchClient(args.api_key) as fft, FinchAnalystClient(args.api_key) as fa:
            for idx, row in df.iterrows():
                header = "\t".join(df.columns)
                row_text = header + "\n" + "\t".join(str(row[c]) for c in df.columns)
                logger.info("Row %d: enriching '%s'...", idx + 1, row.get(args.subject_col, ""))

                enrichment = fft.enrich(row_text)
                enrichment["text"] = row_text
                enrichment = inject_relationships(enrichment, row, args.subject_col, args.subject_type, rel_specs)

                if args.title_col:
                    title = row.get(args.title_col, "(no title)")
                else:
                    try:
                        title = fft.summarize(row_text) or row.get(args.subject_col, "(no title)")
                    except Exception as e:
                        logger.warning("Summarize failed for row %d: %s", idx + 1, e)
                        title = row.get(args.subject_col, "(no title)")

                finch_doc_id = f"{uuid.uuid4()}-en"
                published_time = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                text_len = len(row_text)
                wc = word_count(row_text)
                title_len = len(title)
                title_wc = word_count(title)

                daas_doc = {
                    "title": title,
                    "languageCode": "en",
                    "publishedTimeUtc": published_time,
                    "source": {
                        "name": args.source_name,
                        "type": 3,
                        "mediaType": "Text",
                        **({"location": {"country": args.source_country}} if args.source_country else {}),
                    },
                    "documentText": {
                        "originalText": row_text,
                        "originalTextLang": "en",
                        "originalTextLen": text_len,
                        "originalTextWordCount": wc,
                        "normalizedText": row_text,
                        "normalizedTextLang": "en",
                        "normalizedTextLen": text_len,
                        "normalizedTextWordCount": wc,
                        "additionalContext": title,
                        "additionalCtxLang": "en",
                        "additionalCtxLen": title_len,
                        "additionalCtxWordCount": title_wc,
                        "type": 1,
                    },
                    **({"documentURL": args.document_url} if args.document_url else {}),
                    "filterSets": args.filter_sets,
                    "finchDocId": finch_doc_id,
                    "finchEnrichments": enrichment,
                }

                full_payload = {
                    "document": daas_doc,
                    "doAlerts": False,
                    "doAskFinchEmbed": False,
                    "doNgram": False,
                }

                if args.write_enrichment:
                    enrichment_path = f"{args.data_file}.row{idx + 1}.enrichment.json"
                    with open(enrichment_path, "w", encoding="utf-8") as ef:
                        json.dump(enrichment, ef, indent=2, ensure_ascii=False)
                    logger.info("Enrichment written to %s", enrichment_path)

                if args.write_payload:
                    payload_path = f"{args.data_file}.row{idx + 1}.post_payload.json"
                    with open(payload_path, "w", encoding="utf-8") as pf:
                        json.dump(full_payload, pf, indent=2, ensure_ascii=False)
                    logger.info("Payload written to %s", payload_path)
                else:
                    logger.debug("POST payload: %s", json.dumps(full_payload, indent=2))

                if args.skip_ingest:
                    continue

                result = fa.ingest_load(document=daas_doc, do_ask_finch_embed=True)
                logger.info("Row %d ingested: %s", idx + 1, result.get("id"))
                print(json.dumps(result))

    except _requests.exceptions.ConnectionError as e:
        logger.error("API connection failed: %s", e)
