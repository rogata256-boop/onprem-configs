"""
Submit a previously generated FFT enrichment JSON to Finch Analyst.

The enrichment JSON must contain a 'text' field (produced by text_enrich.py
with returnText=True). Reads from a file path or stdin when no file is given.
"""

import datetime
import json
import logging
import sys
import uuid

from finch_clients import FinchAnalystClient

sys.stdout.reconfigure(encoding="utf-8")

logger = logging.getLogger(__name__)


def word_count(text):
    return len(text.split())


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Submit an FFT enrichment JSON to Finch Analyst."
    )
    parser.add_argument("enrichment", nargs="?", help="Path to FFT enrichment JSON file (reads stdin if omitted)")
    parser.add_argument("api_key", nargs="?", help="Bearer token for Finch Analyst API")
    parser.add_argument("--title", default=None, help="Document title (required if enrichment JSON has no suitable title)")
    parser.add_argument("--source-name", default="Text", help="Source name (default: 'Text')")
    parser.add_argument("--source-country", default=None, help="Source country (sets source.location.country)")
    parser.add_argument("--document-url", default=None, help="URL to include as documentURL (omitted if not provided)")
    parser.add_argument("--filter-sets", nargs="+", default=["Text Evaluation"],
                        metavar="SET", help="Filter sets for the document (default: 'Text Evaluation')")
    parser.add_argument("--write-payload", action="store_true",
                        help="Write POST payload to <enrichment>.post_payload.json (or enrich_ingest.post_payload.json for stdin)")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging verbosity (default: INFO)")
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level, format="%(levelname)s: %(message)s", stream=sys.stderr)

    if args.enrichment:
        with open(args.enrichment, encoding="utf-8") as f:
            enrichment = json.load(f)
        output_path = args.enrichment
    else:
        logger.info("Reading enrichment JSON from stdin...")
        enrichment = json.load(sys.stdin)
        output_path = None

    text = enrichment.get("text", "")
    if not text:
        logger.error("Enrichment JSON does not contain a 'text' field. Re-run text_enrich.py to regenerate.")
        sys.exit(1)

    import os
    import requests as _requests
    try:
        if args.title:
            title = args.title
        elif output_path:
            title = os.path.basename(output_path)
        else:
            title = "(no title)"

        finch_doc_id = f"{uuid.uuid4()}-en"
        published_time = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        text_len = len(text)
        wc = word_count(text)
        title_len = len(title)
        title_wc = word_count(title)

        daas_doc = {
            "title": title,
            "languageCode": "en",
            "publishedTimeUtc": published_time,
            "source": {
                "name": args.source_name,
                "type": 3,
                "mediaType": "Text",
                **({"location": {"country": args.source_country}} if args.source_country else {}),
            },
            "documentText": {
                "originalText": text,
                "originalTextLang": "en",
                "originalTextLen": text_len,
                "originalTextWordCount": wc,
                "normalizedText": text,
                "normalizedTextLang": "en",
                "normalizedTextLen": text_len,
                "normalizedTextWordCount": wc,
                "additionalContext": title,
                "additionalCtxLang": "en",
                "additionalCtxLen": title_len,
                "additionalCtxWordCount": title_wc,
                "type": 1,
            },
            **({"documentURL": args.document_url} if args.document_url else {}),
            "filterSets": args.filter_sets,
            "finchDocId": finch_doc_id,
            "finchEnrichments": enrichment,
        }

        full_payload = {
            "document": daas_doc,
            "doAlerts": False,
            "doAskFinchEmbed": False,
            "doNgram": False,
        }

        if args.write_payload:
            payload_path = (output_path or "enrich_ingest") + ".post_payload.json"
            with open(payload_path, "w", encoding="utf-8") as pf:
                json.dump(full_payload, pf, indent=2, ensure_ascii=False)
            logger.info("POST payload written to %s", payload_path)
        else:
            logger.debug("POST payload: %s", json.dumps(full_payload, indent=2))

        logger.info("Sending to Finch Analyst API...")
        with FinchAnalystClient(args.api_key) as client:
            ingest_result = client.ingest_load(document=daas_doc, do_ask_finch_embed=True)
        print(json.dumps(ingest_result))

    except _requests.exceptions.ConnectionError as e:
        logger.error("API connection failed: %s", e)
