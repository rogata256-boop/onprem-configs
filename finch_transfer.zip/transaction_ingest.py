"""
Transaction data ingestion pipeline.

For each row in a TSV/CSV transaction file:
  1. Rewrite the row as natural language text and submit to FFT
  2. Inject a paymentRecipient relationship from PAYMENT_CARD -> ORGANIZATION
     with transaction date and amount as predicate properties
  3. Ingest the enriched document into Finch Analyst

Usage:
    python3 transaction_ingest.py <data_file> <api_key> [options]
"""

import datetime
import json
import logging
import sys
import uuid

import pandas as pd

from finch_clients import FinchClient, FinchAnalystClient

sys.stdout.reconfigure(encoding="utf-8")

logger = logging.getLogger(__name__)

ORGANIZATION_TYPES = {"ORGANIZATION", "ORGANIZATION/COMPANY"}


def word_count(text):
    return len(text.split())


def find_payment_card(entities, card_number):
    """Find PAYMENT_CARD entity matching card_number (ignoring spaces)."""
    card_norm = card_number.replace(" ", "")
    for e in entities:
        if e.get("type") == "PAYMENT_CARD":
            if e.get("label", "").replace(" ", "") == card_norm:
                return e
    return None


def find_organization(entities, recipient):
    """Find an ORGANIZATION entity whose extractedText appears in recipient."""
    for e in entities:
        if e.get("type") not in ORGANIZATION_TYPES:
            continue
        for mention in e.get("mentions", []):
            extracted = mention.get("extractedText", "")
            if extracted and extracted in recipient:
                return e
    return None


def make_relationship(card_entity, org_entity, sentence, card_number, recipient,
                      transaction_date, amount):
    card_start = sentence.find(card_number)
    card_stop = card_start + len(card_number) if card_start != -1 else 0
    org_label = org_entity["label"]
    org_start = sentence.find(recipient)
    org_stop = org_start + len(recipient) if org_start != -1 else 0

    def entity_ref(e, start, stop):
        ref = {
            "anchor": e["label"],
            "internalRef": e.get("internalRef", ""),
            "label": e["label"],
            "start": start,
            "stop": stop,
            "type": e["type"],
        }
        if e.get("syntheticId"):
            ref["syntheticId"] = e["syntheticId"]
        if e.get("disambiguated"):
            ref["id"] = e["disambiguated"]["id"]
        return ref

    return {
        "confidence": 1.0,
        "evidence": {
            "sentence": sentence,
            "start": 0,
            "stop": len(sentence),
        },
        "originalType": "paymentRecipient",
        "predicate": {
            "bidirectional": False,
            "properties": {
                "status": "Current",
                "transactionDate": transaction_date,
                "amount": amount,
            },
            "type": "paymentRecipient",
        },
        "subject": entity_ref(card_entity, card_start, card_stop),
        "object": entity_ref(org_entity, org_start, org_stop),
    }


def row_to_text(date, card, recipient, amount):
    return (
        f"Payment card {card} was used to pay {recipient} "
        f"for the amount {amount} on {date}."
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Enrich and ingest transaction data row-by-row into Finch Analyst."
    )
    parser.add_argument("data_file", help="Path to TSV or CSV transaction file")
    parser.add_argument("api_key", nargs="?", help="Bearer token for Finch APIs")
    parser.add_argument("--separator", default="\t", help="Field separator (default: tab)")
    parser.add_argument("--date-col", default="transaction_date")
    parser.add_argument("--card-col", default="payment_card")
    parser.add_argument("--recipient-col", default="payment_recipient")
    parser.add_argument("--amount-col", default="payment_amount")
    parser.add_argument("--source-name", default="Text", help="Source name (default: 'Text')")
    parser.add_argument("--source-country", default=None, help="Source country")
    parser.add_argument("--document-url", default=None)
    parser.add_argument("--filter-sets", nargs="+", default=["Text Evaluation"], metavar="SET")
    parser.add_argument("--write-payload", action="store_true")
    parser.add_argument("--write-enrichment", action="store_true",
                        help="Write each row's FFT enrichment JSON (with relationships) to <data_file>.row<N>.enrichment.json")
    parser.add_argument("--skip-ingest", action="store_true",
                        help="Skip FA ingestion (useful with --write-enrichment)")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level, format="%(levelname)s: %(message)s",
                        stream=sys.stderr)

    df = pd.read_csv(args.data_file, sep=args.separator, dtype=str).fillna("")

    for col in [args.date_col, args.card_col, args.recipient_col, args.amount_col]:
        if col not in df.columns:
            logger.error("Column '%s' not found in data file.", col)
            sys.exit(1)

    import requests as _requests
    try:
        with FinchClient(args.api_key) as fft, FinchAnalystClient(args.api_key) as fa:
            for idx, row in df.iterrows():
                date = row[args.date_col]
                card = row[args.card_col]
                recipient = row[args.recipient_col]
                amount = row[args.amount_col]

                text = row_to_text(date, card, recipient, amount)
                logger.info("Row %d: enriching card %s -> %s...", idx + 1, card, recipient)

                enrichment = fft.enrich(text)
                enrichment["text"] = text

                # Inject relationship
                card_entity = find_payment_card(enrichment["entities"], card)
                org_entity = find_organization(enrichment["entities"], recipient)

                if card_entity and org_entity:
                    rel = make_relationship(card_entity, org_entity, text,
                                            card, recipient, date, amount)
                    enrichment.setdefault("relationships", []).append(rel)
                    logger.debug("Injected paymentRecipient: %s -> %s", card, org_entity["label"])
                else:
                    if not card_entity:
                        logger.warning("Row %d: no PAYMENT_CARD entity for '%s'", idx + 1, card)
                    if not org_entity:
                        logger.warning("Row %d: no ORGANIZATION entity for '%s'", idx + 1, recipient)

                # Title: "<card> -> <recipient> (<date>)"
                title = f"{card} -> {recipient} ({date})"

                finch_doc_id = f"{uuid.uuid4()}-en"
                published_time = datetime.datetime.now(datetime.timezone.utc).strftime(
                    "%Y-%m-%dT%H:%M:%SZ")
                text_len = len(text)
                wc = word_count(text)
                title_len = len(title)
                title_wc = word_count(title)

                daas_doc = {
                    "title": title,
                    "languageCode": "en",
                    "publishedTimeUtc": published_time,
                    "source": {
                        "name": args.source_name,
                        "type": 3,
                        "mediaType": "Text",
                        **({"location": {"country": args.source_country}}
                           if args.source_country else {}),
                    },
                    "documentText": {
                        "originalText": text,
                        "originalTextLang": "en",
                        "originalTextLen": text_len,
                        "originalTextWordCount": wc,
                        "normalizedText": text,
                        "normalizedTextLang": "en",
                        "normalizedTextLen": text_len,
                        "normalizedTextWordCount": wc,
                        "additionalContext": title,
                        "additionalCtxLang": "en",
                        "additionalCtxLen": title_len,
                        "additionalCtxWordCount": title_wc,
                        "type": 1,
                    },
                    **({"documentURL": args.document_url} if args.document_url else {}),
                    "filterSets": args.filter_sets,
                    "finchDocId": finch_doc_id,
                    "finchEnrichments": enrichment,
                }

                full_payload = {
                    "document": daas_doc,
                    "doAlerts": False,
                    "doAskFinchEmbed": False,
                    "doNgram": False,
                }

                if args.write_enrichment:
                    enrichment_path = f"{args.data_file}.row{idx + 1}.enrichment.json"
                    with open(enrichment_path, "w", encoding="utf-8") as ef:
                        json.dump(enrichment, ef, indent=2, ensure_ascii=False)
                    logger.info("Enrichment written to %s", enrichment_path)

                if args.write_payload:
                    payload_path = f"{args.data_file}.row{idx + 1}.post_payload.json"
                    with open(payload_path, "w", encoding="utf-8") as pf:
                        json.dump(full_payload, pf, indent=2, ensure_ascii=False)
                    logger.info("Payload written to %s", payload_path)
                else:
                    logger.debug("POST payload: %s", json.dumps(full_payload, indent=2))

                if args.skip_ingest:
                    continue

                result = fa.ingest_load(document=daas_doc, do_ask_finch_embed=True)
                logger.info("Row %d ingested: %s", idx + 1, result.get("id"))
                print(json.dumps(result))

    except _requests.exceptions.ConnectionError as e:
        logger.error("API connection failed: %s", e)
