"""
Translation service implementations.

To add the LTT service: fill in LTTTranslationService.translate() below.
"""

class GoogleTranslationService:
    """Translation via Google Translate (requires internet access and deep-translator package).

    Uses langdetect to skip API calls for text already in English.
    """

    skip_detection = False  # eml_translator will call detect_language() before translating

    def translate(self, text: str, src: str = "auto", dest: str = "en") -> str:
        try:
            from deep_translator import GoogleTranslator
        except ImportError:
            raise ImportError(
                "deep-translator is required for Google Translate. "
                "Install it with: pip install deep-translator"
            )
        return GoogleTranslator(source=src, target=dest).translate(text)


class LTTTranslationService:
    """Translation via the proprietary LTT service.

    Handles language autodetection internally, so pre-detection is skipped.
    Fill in the implementation of translate() before deploying.
    """

    skip_detection = True  # LTT autodetects; eml_translator will always pass text through

    def translate(self, text: str, src: str = "auto", dest: str = "en") -> str:
        raise NotImplementedError("LTT translation service is not yet implemented.")


SERVICES = {
    "google": GoogleTranslationService,
    "ltt": LTTTranslationService,
}


def get_translator(name: str):
    """Return an instantiated translation service by name ('google' or 'ltt')."""
    if name not in SERVICES:
        raise ValueError(f"Unknown translator '{name}'. Choose from: {list(SERVICES)}")
    return SERVICES[name]()
