"""
Enrich plain text via Finch For Text API and print the enrichment JSON.

Reads from a file path or stdin when no file is given.
Optionally translates text to English before enrichment.
"""

import json
import logging
import sys

from finch_clients import FinchClient

sys.stdout.reconfigure(encoding="utf-8")

logger = logging.getLogger(__name__)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Enrich plain text via Finch For Text API.")
    parser.add_argument("file", nargs="?", help="Path to text file (reads stdin if omitted)")
    parser.add_argument("api_key", nargs="?", help="Bearer token for Finch FFT API")
    parser.add_argument("--translate", action="store_true", help="Translate text to English before enrichment")
    parser.add_argument("--translator", default="google", choices=["google", "ltt"],
                        help="Translation service to use (default: google)")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging verbosity (default: INFO)")
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level, format="%(levelname)s: %(message)s", stream=sys.stderr)

    if args.file:
        with open(args.file, encoding="utf-8") as f:
            text = f.read()
    else:
        logger.info("Reading from stdin...")
        text = sys.stdin.read()

    text = text.strip()
    if not text:
        logger.error("No text provided.")
        sys.exit(1)

    if args.translate:
        from translators import get_translator
        from eml_translator import translate_chunks, detect_language, CHUNK_SIZE
        translator = get_translator(args.translator)
        if translator.skip_detection or detect_language(text) != "en":
            logger.info("Translating text to English...")
            try:
                text = translate_chunks(text, translator, chunk_size=CHUNK_SIZE)
            except Exception as e:
                logger.error("Translation failed: %s", e)
                sys.exit(1)
        else:
            logger.info("Text already in English, skipping translation.")

    import requests as _requests
    try:
        logger.info("Sending to Finch For Text API...")
        with FinchClient(args.api_key) as client:
            result = client.enrich(text)
        result["text"] = text
        print(json.dumps(result, indent=2))
    except _requests.exceptions.ConnectionError as e:
        logger.error("API connection failed: %s", e)
