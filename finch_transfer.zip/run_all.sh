# Endpoint URLs can be overridden by setting these environment variables:
#   FINCH_FFT_URL  - Finch For Text API base URL
#   FINCH_FA_URL   - Finch Analyst API base URL
export FINCH_FFT_URL="${FINCH_FFT_URL:-https://text-api-dev.dev.finchai.com/}"
export FINCH_FA_URL="${FINCH_FA_URL:-https://fa-api-dev.dev.finchai.com}"

DIR="${1:?Usage: $0 <directory> [api-key] [source-name] [translator] [extra-args...]}"
API_KEY="${2:-}"
SOURCE_NAME="${3:-}"
TRANSLATOR="${4:-}"
shift 4
EXTRA_ARGS=("$@")

for eml in "$DIR"/*.eml; do
    [ -f "$eml" ] || { echo "No .eml files found in $DIR"; exit 1; }
    echo "Processing: $eml"
    python3 eml_translator.py "$eml" $API_KEY --write-payload \
        ${SOURCE_NAME:+--source-name "$SOURCE_NAME"} \
        ${TRANSLATOR:+--translator "$TRANSLATOR"} \
        "${EXTRA_ARGS[@]}"
done
