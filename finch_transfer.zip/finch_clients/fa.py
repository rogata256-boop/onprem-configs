"""
Finch Analyst (FA) API client.
Requires: pip install requests
"""

import logging
import os
import urllib3
import requests

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

FINCH_FA_BASE_URL = os.environ.get("FINCH_FA_URL", "https://fa-api-dev.dev.finchai.com")

logger = logging.getLogger(__name__)


class FinchAnalystClient:
    """Client for the Finch Analyst REST API."""

    def __init__(self, api_key: str, base_url: str = FINCH_FA_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        self._session.verify = False

    def ingest_load(
        self,
        document: dict,
        do_alerts: bool = False,
        do_ask_finch_embed: bool = False,
        do_ngram: bool = False,
        restricted_access: bool = False,
        additional_controls: list = None,
    ) -> dict:
        """
        Ingest a single pre-enriched document into Elasticsearch.

        Args:
            document:            The pre-enriched DaasDocument object (required).
            do_alerts:           Trigger alert processing for the document.
            do_ask_finch_embed:  Generate and store AskFinch vector embeddings.
            do_ngram:            Add document entities to the Ngram index.
            restricted_access:   (Unused in v2) Restrict access to the document.
            additional_controls: (Unused in v2) Additional control tags.

        Returns:
            Parsed JSON response as a dict, e.g.:
            {"id": "...", "title": "...", "loadDate": "..."}

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        payload = {
            "document": document,
            "doAlerts": do_alerts,
            "doAskFinchEmbed": do_ask_finch_embed,
            "doNgram": do_ngram,
        }

        if restricted_access:
            payload["restrictedAccess"] = restricted_access
        if additional_controls is not None:
            payload["additionalControls"] = additional_controls

        response = self._session.post(
            f"{self.base_url}/fa/api/v2/ingest/load",
            json=payload,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logger.error("HTTP error: %s", e)
            logger.error("Response body: %s", response.text)
            raise
        return response.json()

    def close(self):
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
