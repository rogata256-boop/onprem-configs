"""
Finch For Text (FFT) API client.
Requires: pip install requests
"""

import logging
import os
import urllib3
import requests

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

FINCH_FFT_BASE_URL = os.environ.get("FINCH_FFT_URL", "https://text-api-dev.dev.finchai.com/")


class FinchClient:
    """Client for the Finch For Text REST API."""

    def __init__(self, api_key: str, base_url: str = FINCH_FFT_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        self._session.verify = False

    def enrich(
        self,
        text: str,
        language_code: str = "en",
        disambiguate: bool = True,
        mentions: bool = True,
        entities: list = None,
        relationships: bool = True,
        **kwargs,
    ) -> dict:
        """
        Submit text to the /api/v2/enrich endpoint.

        Args:
            text:           The input text to analyse.
            language_code:  BCP-47 language code (default "en").
            disambiguate:   Resolve entity mentions against the knowledge base.
            mentions:       Include all mentions of each entity in the response.
            entities:       List of entity types to extract, e.g. ["Person", "Place"].
                            Pass ["*"] (default) to extract all types.
            relationships:  Extract entity relationships.
            **kwargs:       Any additional fields to include in the request body.

        Returns:
            Parsed JSON response as a dict.

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        if entities is None:
            entities = ["*"]

        payload = {
            "text": text,
            "languageCode": language_code,
            "disambiguate": disambiguate,
            "mentions": mentions,
            "entities": entities,
            "relationships": relationships,
            **kwargs,
        }

        response = self._session.post(
            f"{self.base_url}/api/v2/enrich",
            json=payload,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error: %s", e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def convert_doc(
        self,
        filename: str,
        file_bytes: bytes,
        content_type: str = "application/octet-stream",
    ) -> dict:
        """
        Submit a file to the /api/v2/convert-doc endpoint to extract text.

        Args:
            filename:     Original filename (used for the multipart field).
            file_bytes:   Raw bytes of the file.
            content_type: MIME type of the file. Use 'application/octet-stream'
                          for binary documents (.pdf, .docx, etc.), the
                          appropriate text/* type for text files, and image/*
                          for images.

        Returns:
            Parsed JSON response as a dict with 'text' and 'elements' fields.

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        # Send the file bytes as the raw request body. The session-level
        # Content-Type: application/json must be overridden with the file's type.
        response = self._session.put(
            f"{self.base_url}/api/v2/convert-doc",
            data=file_bytes,
            headers={
                "Authorization": self._session.headers["Authorization"],
                "Accept": "application/json",
                "Content-Type": content_type,
            },
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error: %s", e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def summarize(self, text: str, language_code: str = "en", max_sentences: int = 1) -> str | None:
        """
        Submit text to the /api/v1/summarize endpoint.

        Returns the summary string, or None if the request fails or returns no summary.
        """
        response = self._session.post(
            f"{self.base_url}/api/v1/summarize",
            json={"text": text, "languageCode": language_code, "summaryModel": "News", "maxSentences": max_sentences},
            timeout=30,
        )
        if not response.ok:
            return None
        data = response.json()
        return data.get("summary") or data.get("title") or None

    def create_entity(self, knowledgebase: str, entity: dict) -> dict:
        """
        Create a new entity in the Finch knowledgebase.

        Args:
            knowledgebase:  The entity type: "PERSON", "ORGANIZATION", or "THING".
            entity:         Entity payload dict. For PERSON, typically includes:
                              label, description, document (min 256 chars),
                              prominence (0.0–1.0), nameVariations, identifiers,
                              languageFields.

        Returns:
            Parsed JSON response as a dict (server-assigned fields such as id,
            collectionId, version, and status will be present). The HTTP response
            also carries a Location header with the URI of the new entity.

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        response = self._session.post(
            f"{self.base_url}/api/v2/entities/{knowledgebase}",
            json=entity,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error creating entity: %s", e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def get_entity(self, entity_id: str, select: str = None) -> dict:
        """
        Retrieve an entity from the Finch knowledgebase by its ID.

        Args:
            entity_id:  The Finch entity ID (e.g. "671740526593").
            select:     Optional comma-separated list of fields to return
                        (e.g. "id,label,urls[*]"). All fields returned by default.

        Returns:
            Parsed JSON response as a dict.

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        params = {}
        if select:
            params["select"] = select
        response = self._session.get(
            f"{self.base_url}/api/v2/entities/{entity_id}",
            params=params,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error retrieving entity %s: %s", entity_id, e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def update_entity(self, entity_id: str, entity: dict) -> dict:
        """
        Replace an existing entity in the Finch knowledgebase.

        The entity dict must include all required fields plus any server-assigned
        fields returned by create_entity (id, collectionId, version, etc.) —
        the PUT replaces all entity data.

        Args:
            entity_id:  The Finch entity ID to update (e.g. "671740526593").
            entity:     Full entity payload dict (see put.json for structure).

        Returns:
            Parsed JSON response as a dict.

        Raises:
            requests.HTTPError: On a non-2xx response (404 = not found,
                                409 = concurrency conflict, 423 = locked).
        """
        response = self._session.put(
            f"{self.base_url}/api/v2/entities/{entity_id}",
            json=entity,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error updating entity %s: %s", entity_id, e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def search_entities(
        self,
        entity_type: str,
        query: str,
        max_answers: int = 100,
        select: str = None,
    ) -> list:
        """
        Search for entities by name and type.

        Args:
            entity_type:  The entity type to search: "PERSON", "ORGANIZATION", or "THING".
            query:        Name or string to search for (e.g. "Richard Ogata").
            max_answers:  Maximum number of results to return (default 100).
            select:       Optional comma-separated list of fields to include
                          (e.g. "id,label,urls[*]"). All fields returned by default.

        Returns:
            List of result dicts, each with a "document" (entity data) and
            "score" (0.0–1.0 relevance rank).

        Raises:
            requests.HTTPError: On a non-2xx response.
        """
        params = {"query": query, "maxAnswers": max_answers}
        if select:
            params["select"] = select
        response = self._session.get(
            f"{self.base_url}/api/v2/entities/{entity_type}",
            params=params,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error searching entities: %s", e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json().get("results", [])

    def search_entities_ai(self, entity: dict, entity_type: str = None) -> dict:
        """
        Search for matching entities in the Finch knowledgebase using an AI agent.

        Args:
            entity:       Entity object to search for (any dict describing the entity).
            entity_type:  The entity type: "PERSON", "ORGANIZATION", or "THING".
                          Required if not already present as "type" in entity.

        Returns:
            Dict with "justification" (str), "results" (list of Finch ID strings),
            and "nearMatches" (list).

        Raises:
            ValueError: If no entity type is provided.
            requests.HTTPError: On a non-2xx response.
        """
        payload = dict(entity)
        if entity_type:
            payload["type"] = entity_type
        if "type" not in payload:
            raise ValueError("entity_type is required (pass entity_type= or include 'type' in entity)")
        response = self._session.post(
            f"{self.base_url}/api/v2/entities/search",
            json={"entity": payload},
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error in AI entity search: %s", e)
            logging.error("Response body: %s", response.text)
            raise
        return response.json()

    def delete_entity(self, entity_id: str) -> None:
        """
        Delete an entity from the Finch knowledgebase.

        Args:
            entity_id:  The Finch entity ID to delete (e.g. "671740002305").

        Raises:
            requests.HTTPError: On a non-2xx response (404 = not found,
                                423 = locked).
        """
        response = self._session.delete(
            f"{self.base_url}/api/v2/entities/{entity_id}",
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error deleting entity %s: %s", entity_id, e)
            logging.error("Response body: %s", response.text)
            raise

    def close(self):
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
