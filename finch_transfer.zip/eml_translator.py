"""
Parse an .eml file and translate its content from Russian to English.
Requires: pip install deep-translator
"""

import datetime
import email
import io
import json
import os
import logging
import re
import sys
import html
from email import policy
from email.header import decode_header
from email.parser import BytesParser
from email.utils import getaddresses, formataddr, parsedate_to_datetime
from translators import get_translator
from finch_clients import FinchClient, FinchAnalystClient

sys.stdout.reconfigure(encoding="utf-8")

logger = logging.getLogger(__name__)

CHUNK_SIZE = 1500
MAX_MESSAGE_LENGTH = 100_000

ATTACHMENT_TYPE_MAP = {
    "spreadsheet": {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
    },
    "pdf":  {"application/pdf"},
    "word": {"application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
}


def decode_email_header(value):
    """Decode an RFC 2047 encoded email header into a plain string."""
    parts = decode_header(value)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(part)
    return "".join(decoded)


def detect_language(text, sample_size=500):
    """Return BCP-47 language code for the text sample, or 'en' on failure.

    Requires langdetect (only used with --translator google).
    """
    try:
        from langdetect import detect, LangDetectException
        try:
            return detect(text[:sample_size])
        except LangDetectException:
            return "en"
    except ImportError:
        raise ImportError(
            "langdetect is required when using --translator google. "
            "Install it with: pip install langdetect"
        )


def normalize_whitespace(text):
    """Collapse runs of blank/whitespace-only lines to a single blank line
    and strip trailing whitespace from each line."""
    lines = [line.rstrip() for line in text.splitlines()]
    cleaned, prev_blank = [], False
    for line in lines:
        is_blank = not line.strip()
        if is_blank and prev_blank:
            continue
        cleaned.append(line)
        prev_blank = is_blank
    return "\n".join(cleaned).strip()


def get_text_parts(msg):
    """Extract plain text and HTML text from email parts."""
    plain, html_body = [], []

    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_disposition() == "attachment":
                continue  # handled separately by extract_attachments
            ctype = part.get_content_type()
            charset = part.get_content_charset() or "utf-8"
            payload = part.get_payload(decode=True)
            if payload is None:
                continue
            text = payload.decode(charset, errors="replace")
            if ctype == "text/plain":
                plain.append(text)
            elif ctype == "text/html":
                html_body.append(text)
    else:
        charset = msg.get_content_charset() or "utf-8"
        payload = msg.get_payload(decode=True)
        if payload:
            text = payload.decode(charset, errors="replace")
            if msg.get_content_type() == "text/html":
                html_body.append(text)
            else:
                plain.append(text)

    return plain, html_body


def extract_attachments(msg):
    """Return list of (filename, content_type, bytes) for all email attachments.

    Skips inline parts (e.g. embedded images) and any part without a payload.
    """
    attachments = []
    for part in msg.walk():
        disposition = part.get_content_disposition()
        filename = part.get_filename()
        # Include explicit attachments; skip inline parts (e.g. CID-referenced images)
        if disposition == "inline" or (not filename and disposition != "attachment"):
            continue
        payload = part.get_payload(decode=True)
        if payload is None:
            continue
        fname = decode_email_header(filename) if filename else f"attachment_{len(attachments) + 1}"
        attachments.append((fname, part.get_content_type(), payload))
    return attachments


def strip_html(text):
    """Strip HTML tags, preserving line breaks for block-level elements."""
    # Remove style and script blocks entirely (must be before generic tag stripping)
    text = re.sub(
        r"<(style|script)\b[^>]*>.*?</(style|script)>",
        "",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # Replace <br> with newline
    text = re.sub(r"<br\b[^>]*>", "\n", text, flags=re.IGNORECASE)
    # Replace opening block-level tags with double newline (paragraph break)
    text = re.sub(r"<(div|p|tr|li|h[1-6])\b[^>]*>", "\n\n", text, flags=re.IGNORECASE)
    # Remove closing block-level tags
    text = re.sub(r"</(div|p|tr|li|h[1-6])>", "", text, flags=re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    # Normalize non-breaking spaces
    text = text.replace("\u00a0", " ")
    return normalize_whitespace(text)


def translate_chunks(text, translator, src="auto", dest="en", chunk_size=CHUNK_SIZE):
    """
    Split text on paragraph boundaries and translate each chunk, preserving
    blank lines. Falls back to hard character splits if a single paragraph
    exceeds chunk_size.

    Args:
        translator: a translation service instance (from translators.py).
    """
    # Split into paragraphs, keeping the double-newline separators
    paragraphs = re.split(r"(\n\n+)", text)

    def flush(s):
        """Append s to chunks, hard-splitting if it exceeds chunk_size."""
        if len(s) > chunk_size:
            for i in range(0, len(s), chunk_size):
                chunks.append(s[i:i + chunk_size])
        else:
            chunks.append(s)

    chunks, current = [], ""
    for part in paragraphs:
        if len(current) + len(part) > chunk_size and current:
            flush(current)
            current = part if len(part.strip()) <= chunk_size else ""
            if len(part.strip()) > chunk_size:
                flush(part)
        else:
            current += part
    if current:
        flush(current)

    results = []
    for i, chunk in enumerate(chunks):
        if not chunk.strip():
            results.append(chunk)  # preserve blank separators as-is
            continue
        logger.debug("Translating chunk %d/%d, %d chars...", i + 1, len(chunks), len(chunk))
        results.append(translator.translate(chunk, src=src, dest=dest))

    return "".join(results)


def rewrite_local_domains(header_value):
    """Rewrite .local TLD to .com in email addresses (not display names)."""
    if not header_value:
        return header_value
    addresses = getaddresses([header_value])
    result = []
    for name, addr in addresses:
        if addr.lower().endswith(".local"):
            addr = addr[:addr.rfind(".")] + ".com"
        if name:
            result.append(f"{name} <{addr}>" if addr else name)
        else:
            result.append(addr)
    return ", ".join(result)


def translate_address_names(header_value, translator):
    """Translate display names in an address header, leaving <email> parts untouched."""
    if not header_value:
        return header_value
    addresses = getaddresses([header_value])
    result = []
    for name, addr in addresses:
        if name and re.search(r"[\u0400-\u04FF]", name):
            try:
                name = translator.translate(name, src="auto", dest="en")
            except Exception as e:
                logger.warning("Name translation failed for '%s': %s", name, e)
        if name and name != addr:
            result.append(f"{name} <{addr}>" if addr else name)
        else:
            result.append(addr)
    return ", ".join(result)


def word_count(text):
    """Return whitespace-delimited word count."""
    return len(text.split())


def to_iso8601(date_str):
    """Convert an RFC 2822 email date string to ISO 8601 UTC, e.g. '2025-11-12T23:40:43Z'."""
    try:
        dt = parsedate_to_datetime(date_str)
        dt_utc = dt.astimezone(datetime.timezone.utc)
        return dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        logger.warning("Could not parse date '%s', using raw value", date_str)
        return date_str



def build_email_header_string(sender, recipient, cc, date, subject_line):
    """Reconstruct the email header as a single string."""
    parts = [f"From: {sender}"]
    if recipient:
        parts.append(f"To: {recipient}")
    if cc:
        parts.append(f"CC: {cc}")
    if date:
        parts.append(f"Date: {date}")
    if subject_line:
        parts.append(f"Subject: {subject_line}")
    return "\n".join(parts)


def find_email_entity(entities, address):
    """Find the FFT EMAIL entity whose label matches the given address."""
    address = address.strip().lower()
    for e in entities:
        if e.get("type") == "EMAIL" and e.get("label", "").lower() == address:
            return e
    return None


def make_email_sent_relationship(header, from_entity, to_entity):
    """Build an Email-Sent relationship dict between two EMAIL entities."""
    from_addr = from_entity["label"]
    to_addr = to_entity["label"]
    from_start = header.find(from_addr)
    from_stop = from_start + len(from_addr) if from_start != -1 else 0
    to_start = header.find(to_addr)
    to_stop = to_start + len(to_addr) if to_start != -1 else 0
    return {
        "confidence": 1.0,
        "evidence": {
            "sentence": header,
            "start": 0,
            "stop": len(header),
        },
        "originalType": "Email-Sent",
        "predicate": {
            "bidirectional": False,
            "properties": {"status": "Current"},
            "type": "Email-Sent",
        },
        "subject": {
            "anchor": from_addr,
            "internalRef": from_entity.get("internalRef", ""),
            "label": from_entity["label"],
            "start": from_start,
            "stop": from_stop,
            "syntheticId": from_entity.get("syntheticId", ""),
            "type": "EMAIL",
            **( {"id": from_entity["disambiguated"]["id"]} if from_entity.get("disambiguated") else {} ),
        },
        "object": {
            "anchor": to_addr,
            "internalRef": to_entity.get("internalRef", ""),
            "label": to_entity["label"],
            "start": to_start,
            "stop": to_stop,
            "syntheticId": to_entity.get("syntheticId", ""),
            "type": "EMAIL",
            **( {"id": to_entity["disambiguated"]["id"]} if to_entity.get("disambiguated") else {} ),
        },
    }


def inject_email_relationships(result, sender, recipient, cc, date, subject_line):
    """Add Email-Sent relationships to FFT result for each From→To/CC pair."""
    entities = result.get("entities", [])
    header = build_email_header_string(sender, recipient, cc, date, subject_line)

    def bare(addr):
        if "<" in addr and ">" in addr:
            return addr[addr.index("<") + 1:addr.index(">")].strip()
        return addr.strip()

    from_addr = bare(sender)
    from_entity = find_email_entity(entities, from_addr)
    if not from_entity:
        logger.warning("Could not find EMAIL entity for sender '%s', skipping relationship injection", from_addr)
        return result

    new_rels = []
    for addr_str in ([recipient] if recipient else []) + ([cc] if cc else []):
        for addr in addr_str.split(","):
            to_addr = bare(addr)
            to_entity = find_email_entity(entities, to_addr)
            if to_entity:
                new_rels.append(make_email_sent_relationship(header, from_entity, to_entity))
            else:
                logger.warning("Could not find EMAIL entity for address '%s', skipping", to_addr)

    result.setdefault("relationships", []).extend(new_rels)
    return result



def extract_attachment_text(data, content_type):
    """Extract plain text from attachment bytes based on content type.

    Supported formats:
    - PDF via pdfminer.six
    - DOCX via python-docx
    - XLSX via openpyxl
    """
    ct = content_type.lower()
    if ct == "application/pdf":
        from pdfminer.high_level import extract_text
        return extract_text(io.BytesIO(data)).strip()
    if ct == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        import docx
        doc = docx.Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs if p.text).strip()
    if ct in (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
    ):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        rows = []
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                line = "\t".join(str(c) for c in row if c is not None)
                if line:
                    rows.append(line)
        return "\n".join(rows).strip()
    raise ValueError(f"Unsupported attachment content type: {content_type}")


def parse_and_translate(eml_path, api_key=None, write_payload=False, write_enrichment=False, skip_ingest=False, source_name="Email", translator=None, process_attachments=True, cache_path=None, exclude_attachment_types=None, max_message_length=MAX_MESSAGE_LENGTH, document_url=None):
    with open(eml_path, "rb") as f:
        msg = BytesParser(policy=policy.default).parse(f)

    # --- Headers ---
    subject   = decode_email_header(msg.get("Subject", "(no subject)"))
    sender    = decode_email_header(msg.get("From", ""))
    recipient = decode_email_header(msg.get("To", ""))
    cc        = decode_email_header(msg.get("CC", "") or msg.get("Cc", ""))
    date      = msg.get("Date", "")

    cache_hit = cache_path is not None and os.path.exists(cache_path)

    if cache_hit:
        logger.info("Loading translated text from cache: %s", cache_path)
        with open(cache_path, encoding="utf-8") as cf:
            output = cf.read()
        # Recover subject_translated from the Subject: line in the cached output
        subject_translated = subject
        for line in output.splitlines():
            if line.startswith("Subject: "):
                subject_translated = line[len("Subject: "):]
                break
        # Still rewrite .local domains so email addresses match FFT entity labels
        sender    = rewrite_local_domains(sender)
        recipient = rewrite_local_domains(recipient)
        cc        = rewrite_local_domains(cc)
        summarize_text = output
    else:
        if translator.skip_detection or detect_language(subject) != "en":
            try:
                subject_translated = translate_chunks(subject, translator, chunk_size=CHUNK_SIZE)
            except Exception as e:
                subject_translated = f"(translation failed: {e})"
        else:
            subject_translated = subject

        sender    = translate_address_names(sender, translator)
        recipient = translate_address_names(recipient, translator)
        cc        = translate_address_names(cc, translator)

        # FFT does not recognise .local domains — rewrite to .com in headers only
        sender    = rewrite_local_domains(sender)
        recipient = rewrite_local_domains(recipient)
        cc        = rewrite_local_domains(cc)

        metadata = (
            f"From: {sender}\n"
            f"To: {recipient}\n"
            f"Date: {date}\n"
            f"Subject: {subject_translated}"
        )

        # --- Body ---
        # Prefer HTML over plain text: for multipart/alternative emails the HTML
        # part is always richer and better structured than the plain text fallback.
        plain_parts, html_parts = get_text_parts(msg)

        if html_parts:
            body = strip_html("\n".join(html_parts))
        elif plain_parts:
            body = "\n".join(plain_parts)
        else:
            body = ""

        body = normalize_whitespace(body)

        if body.strip() and (translator.skip_detection or detect_language(body) != "en"):
            try:
                body_translated = translate_chunks(body, translator, chunk_size=CHUNK_SIZE)
            except Exception as e:
                body_translated = f"(translation failed: {e})"
        elif body.strip():
            body_translated = body
        else:
            body_translated = "(no body text found)"

        output = metadata + "\n\n" + body_translated
        summarize_text = body_translated

    print(output)

    if api_key:
        import requests as _requests
        attachments = [] if cache_hit else (extract_attachments(msg) if process_attachments else [])

        try:
            logger.info("Sending to Finch For Text API...")
            with FinchClient(api_key) as client:
                excluded_mime_types = set()
                for type_name in (exclude_attachment_types or []):
                    excluded_mime_types.update(ATTACHMENT_TYPE_MAP.get(type_name, {type_name}))

                for fname, ct, data in attachments:
                    if ct in excluded_mime_types:
                        logger.info("Skipping excluded attachment type (%s): %s", ct, fname)
                        continue
                    logger.info("Converting attachment: %s (%s)", fname, ct)
                    try:
                        att_text = extract_attachment_text(data, ct)
                        if att_text:
                            if translator.skip_detection or detect_language(att_text) != "en":
                                att_text = translate_chunks(att_text, translator, chunk_size=CHUNK_SIZE)
                            output += f"\n\n--- Attachment: {fname} ---\n{att_text}"
                            logger.debug("Appended %d chars from %s", len(att_text), fname)
                    except Exception as e:
                        logger.warning("Attachment extraction failed for %s: %s", fname, e)

                if max_message_length and len(output) > max_message_length:
                    logger.info("Truncating message from %d to %d characters", len(output), max_message_length)
                    output = output[:max_message_length]

                if cache_path and not cache_hit:
                    with open(cache_path, "w", encoding="utf-8") as cf:
                        cf.write(output)
                    logger.info("Translation cached to %s", cache_path)

                result = client.enrich(output)

                additional_context = subject_translated  # fallback
                try:
                    generated = client.summarize(summarize_text[:3000])
                    if generated:
                        additional_context = generated
                except Exception as e:
                    logger.warning("Title generation failed: %s", e)

            result = inject_email_relationships(result, sender, recipient, cc, date, subject_translated)
            result["text"] = output

            if write_enrichment:
                import re
                safe_title = re.sub(r'[\\/*?:"<>|]', "_", additional_context)[:200]
                enrichment_dir = os.path.dirname(eml_path)
                enrichment_path = os.path.join(enrichment_dir, safe_title + ".enrichment.json")
                counter = 1
                while os.path.exists(enrichment_path):
                    enrichment_path = os.path.join(enrichment_dir, f"{safe_title}.{counter}.enrichment.json")
                    counter += 1
                with open(enrichment_path, "w", encoding="utf-8") as ef:
                    json.dump(result, ef, indent=2, ensure_ascii=False)
                logger.info("Enrichment written to %s", enrichment_path)

            print(json.dumps(result))

            if skip_ingest:
                return

            logger.info("Sending to Finch Analyst API...")
            import uuid
            finch_doc_id = f"{uuid.uuid4()}-en"

            original_text = output
            normalized_text = output

            orig_len        = len(original_text)
            orig_word_count = word_count(original_text)
            norm_len        = len(normalized_text)
            norm_word_count = word_count(normalized_text)

            add_ctx_len        = len(additional_context)
            add_ctx_word_count = word_count(additional_context)

            daas_doc = {
                "title": additional_context,
                "languageCode": "en",
                "publishedTimeUtc": to_iso8601(date),
                "source": {
                    "name":      source_name,
                    "type":      3,
                    "mediaType": "Email",
                },
                "documentText": {
                    "originalText":            original_text,
                    "originalTextLang":        "en",
                    "originalTextLen":         orig_len,
                    "originalTextWordCount":   orig_word_count,
                    "normalizedText":          normalized_text,
                    "normalizedTextLang":      "en",
                    "normalizedTextLen":       norm_len,
                    "normalizedTextWordCount": norm_word_count,
                    "additionalContext":       additional_context,
                    "additionalCtxLang":       "en",
                    "additionalCtxLen":        add_ctx_len,
                    "additionalCtxWordCount":  add_ctx_word_count,
                    "type": 1,
                },
                **({"documentURL": document_url} if document_url else {}),
                "filterSets":       ["Email Evaluation"],
                "finchDocId":       finch_doc_id,
                "finchEnrichments": result,
            }

            full_payload = {
                "document":        daas_doc,
                "doAlerts":        False,
                "doAskFinchEmbed": False,
                "doNgram":         False,
            }

            if write_payload:
                payload_path = eml_path + ".post_payload.json"
                with open(payload_path, "w", encoding="utf-8") as pf:
                    json.dump(full_payload, pf, indent=2, ensure_ascii=False)
                logger.info("POST payload written to %s", payload_path)
            else:
                logger.debug("POST payload: %s", json.dumps(full_payload, indent=2))

            with FinchAnalystClient(api_key) as client:
                ingest_result = client.ingest_load(document=daas_doc, do_ask_finch_embed=True)
            print(json.dumps(ingest_result))

        except _requests.exceptions.ConnectionError as e:
            logger.error("API connection failed: %s", e)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Parse, translate, and ingest an .eml file.")
    parser.add_argument("eml_path", help="Path to the .eml file")
    parser.add_argument("api_key", nargs="?", help="Bearer token for Finch APIs")
    parser.add_argument("--write-payload", action="store_true", help="Write POST payload to <eml_path>.post_payload.json")
    parser.add_argument("--write-enrichment", action="store_true", help="Write FFT enrichment JSON (with relationships) to <eml_path>.enrichment.json")
    parser.add_argument("--skip-ingest", action="store_true", help="Skip FA ingestion (useful with --write-enrichment)")
    parser.add_argument("--source-name", default="Email", help="Source name sent to Finch Analyst API (default: 'Email')")
    parser.add_argument("--translator", default="google", choices=["google", "ltt"], help="Translation service to use (default: google)")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"], help="Logging verbosity (default: INFO)")
    parser.add_argument("--no-attachments", action="store_true", help="Skip attachment extraction and processing")
    parser.add_argument("--exclude-attachment-types", nargs="+", metavar="TYPE",
                        choices=list(ATTACHMENT_TYPE_MAP.keys()),
                        help="Attachment types to skip. Choices: %(choices)s")
    parser.add_argument("--max-message-length", type=int, default=MAX_MESSAGE_LENGTH,
                        help=f"Maximum total message length in characters including attachments (default: {MAX_MESSAGE_LENGTH}, 0 to disable)")
    parser.add_argument("--cache-translations", action="store_true", help="Cache translated output to <eml_path>.en and reuse on subsequent runs to avoid retranslation")
    parser.add_argument("--document-url", default=None, help="URL to include as documentURL in the Finch Analyst payload (omitted if not provided)")
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level, format="%(levelname)s: %(message)s", stream=sys.stderr)

    translator = get_translator(args.translator)
    parse_and_translate(args.eml_path, args.api_key, write_payload=args.write_payload, write_enrichment=args.write_enrichment, skip_ingest=args.skip_ingest, source_name=args.source_name, translator=translator, process_attachments=not args.no_attachments, cache_path=args.eml_path + ".en" if args.cache_translations else None, exclude_attachment_types=args.exclude_attachment_types, max_message_length=args.max_message_length, document_url=args.document_url)
